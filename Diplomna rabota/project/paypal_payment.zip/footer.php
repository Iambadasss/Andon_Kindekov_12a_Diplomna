<section class="footer">

   <div class="box-container">

      <div class="box">
         <h3>Бързи линкове</h3>
         <a href="home.php">Главна страница</a>
         <a href="about.php">За нас</a>
         <a href="shop.php">Магазин</a>
         <a href="contact.php">Контакти</a>
      </div>

      <div class="box">
         <h3>Допълнителни връзки</h3>
         <a href="index.php">Влизане в профил</a>
         <a href="register.php">Регистриране</a>
         <a href="cart.php">Количка</a>
         <a href="orders.php">Поръчки</a>
      </div>

      <div class="box">
         <h3>За връзка с нас</h3>
         <p> <i class="fas fa-phone"></i> 000 000 0000 </p>
         <p> <i class="fas fa-phone"></i> 111 111 1111 </p>
         <p> <i class="fas fa-envelope"></i> istinskiEmail@gmail.com </p>
         <p> <i class="fas fa-map-marker-alt"></i> Пловдив, България - 4000 </p>
      </div>


   </div>


</section>